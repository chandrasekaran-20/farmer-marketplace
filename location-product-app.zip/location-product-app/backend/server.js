// server.js - Express Backend with Location Features
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/farm-products', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Product Schema with Geospatial Index
const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  price: { type: Number, required: true },
  category: { type: String, required: true },
  sellerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  
  // Geospatial location (GeoJSON format)
  location: {
    type: {
      type: String,
      enum: ['Point'],
      required: true
    },
    coordinates: {
      type: [Number], // [longitude, latitude]
      required: true
    }
  },
  
  // Address details
  address: {
    street: String,
    city: String,
    state: String,
    pinCode: String,
    country: { type: String, default: 'India' },
    fullAddress: String
  },
  
  // Location metadata
  locationAccuracy: Number,
  locationMethod: {
    type: String,
    enum: ['auto', 'manual', 'map', 'autocomplete', 'migration']
  },
  
  images: [String],
  status: {
    type: String,
    enum: ['active', 'sold', 'inactive'],
    default: 'active'
  }
}, {
  timestamps: true
});

// Create 2dsphere index for geospatial queries
productSchema.index({ location: '2dsphere' });

const Product = mongoose.model('Product', productSchema);

// ============================================================
// LOCATION ROUTES
// ============================================================

/**
 * POST /api/location/geocode
 * Convert address to coordinates
 */
app.post('/api/location/geocode', async (req, res) => {
  try {
    const { address } = req.body;

    if (!address) {
      return res.status(400).json({
        success: false,
        message: 'Address is required'
      });
    }

    const googleApiKey = process.env.GOOGLE_MAPS_API_KEY;
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${googleApiKey}`;

    const response = await axios.get(url);

    if (response.data.status === 'OK' && response.data.results.length > 0) {
      const result = response.data.results[0];
      const location = result.geometry.location;
      
      // Extract address components
      const addressComponents = result.address_components;
      const addressData = extractAddressFromComponents(addressComponents);
      addressData.fullAddress = result.formatted_address;

      res.json({
        success: true,
        location: {
          coordinates: [location.lng, location.lat],
          formattedAddress: result.formatted_address,
          address: addressData
        }
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Address not found'
      });
    }
  } catch (error) {
    console.error('Geocoding error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to geocode address'
    });
  }
});

/**
 * POST /api/location/reverse-geocode
 * Convert coordinates to address
 */
app.post('/api/location/reverse-geocode', async (req, res) => {
  try {
    const { latitude, longitude } = req.body;

    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        message: 'Latitude and longitude are required'
      });
    }

    const googleApiKey = process.env.GOOGLE_MAPS_API_KEY;
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${googleApiKey}`;

    const response = await axios.get(url);

    if (response.data.status === 'OK' && response.data.results.length > 0) {
      const result = response.data.results[0];
      const addressComponents = result.address_components;
      
      const address = extractAddressFromComponents(addressComponents);
      address.fullAddress = result.formatted_address;

      res.json({
        success: true,
        address
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Address not found for coordinates'
      });
    }
  } catch (error) {
    console.error('Reverse geocoding error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to reverse geocode'
    });
  }
});

/**
 * Helper function to extract address components
 */
function extractAddressFromComponents(components) {
  const address = {
    street: '',
    city: '',
    state: '',
    pinCode: '',
    country: 'India'
  };

  components.forEach(component => {
    const types = component.types;

    if (types.includes('street_number') || types.includes('route')) {
      address.street += component.long_name + ' ';
    }

    if (types.includes('locality') || types.includes('administrative_area_level_2')) {
      address.city = component.long_name;
    }

    if (types.includes('administrative_area_level_1')) {
      address.state = component.long_name;
    }

    if (types.includes('postal_code')) {
      address.pinCode = component.long_name;
    }

    if (types.includes('country')) {
      address.country = component.long_name;
    }
  });

  address.street = address.street.trim();
  return address;
}

// ============================================================
// PRODUCT ROUTES
// ============================================================

/**
 * POST /api/products
 * Create a new product with location
 */
app.post('/api/products', async (req, res) => {
  try {
    const { name, description, price, category, location, sellerId } = req.body;

    // Validation
    if (!name || !price || !category || !location || !location.coordinates) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields'
      });
    }

    // Create product
    const product = new Product({
      name,
      description,
      price,
      category,
      sellerId: sellerId || new mongoose.Types.ObjectId(), // Mock seller ID for demo
      location: {
        type: 'Point',
        coordinates: location.coordinates // [lng, lat]
      },
      address: location.address,
      locationAccuracy: location.accuracy,
      locationMethod: location.method
    });

    await product.save();

    res.status(201).json({
      success: true,
      productId: product._id,
      message: 'Product created successfully'
    });
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create product'
    });
  }
});

/**
 * PATCH /api/products/:productId/location
 * Update product location
 */
app.patch('/api/products/:productId/location', async (req, res) => {
  try {
    const { productId } = req.params;
    const { coordinates, address } = req.body;

    if (!coordinates || coordinates.length !== 2) {
      return res.status(400).json({
        success: false,
        message: 'Valid coordinates are required'
      });
    }

    const product = await Product.findByIdAndUpdate(
      productId,
      {
        location: {
          type: 'Point',
          coordinates: coordinates
        },
        address: address
      },
      { new: true }
    );

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    res.json({
      success: true,
      message: 'Location updated successfully',
      product
    });
  } catch (error) {
    console.error('Update location error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update location'
    });
  }
});

/**
 * GET /api/products/search/nearby
 * Search products by location with distance
 */
app.get('/api/products/search/nearby', async (req, res) => {
  try {
    const {
      latitude,
      longitude,
      radius = 10, // km
      category,
      query,
      minPrice,
      maxPrice,
      page = 1,
      limit = 20
    } = req.query;

    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        message: 'Latitude and longitude are required'
      });
    }

    const lat = parseFloat(latitude);
    const lng = parseFloat(longitude);
    const radiusInMeters = parseFloat(radius) * 1000;

    // Build aggregation pipeline
    const pipeline = [
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [lng, lat]
          },
          distanceField: 'distance',
          maxDistance: radiusInMeters,
          spherical: true,
          distanceMultiplier: 0.001 // Convert to km
        }
      },
      {
        $match: {
          status: 'active'
        }
      }
    ];

    // Add category filter
    if (category) {
      pipeline.push({
        $match: { category: category }
      });
    }

    // Add price filter
    if (minPrice || maxPrice) {
      const priceMatch = {};
      if (minPrice) priceMatch.$gte = parseFloat(minPrice);
      if (maxPrice) priceMatch.$lte = parseFloat(maxPrice);
      pipeline.push({
        $match: { price: priceMatch }
      });
    }

    // Add text search filter
    if (query) {
      pipeline.push({
        $match: {
          $or: [
            { name: { $regex: query, $options: 'i' } },
            { description: { $regex: query, $options: 'i' } }
          ]
        }
      });
    }

    // Get total count
    const countPipeline = [...pipeline, { $count: 'total' }];
    const countResult = await Product.aggregate(countPipeline);
    const total = countResult.length > 0 ? countResult[0].total : 0;

    // Add pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    pipeline.push({ $skip: skip });
    pipeline.push({ $limit: parseInt(limit) });

    // Execute query
    const products = await Product.aggregate(pipeline);

    res.json({
      success: true,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      products
    });
  } catch (error) {
    console.error('Search products error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to search products'
    });
  }
});

/**
 * GET /api/products/map
 * Get products for map view (within bounds)
 */
app.get('/api/products/map', async (req, res) => {
  try {
    const { bounds, category } = req.query;

    if (!bounds) {
      return res.status(400).json({
        success: false,
        message: 'Bounds are required'
      });
    }

    const [south, west, north, east] = bounds.split(',').map(parseFloat);

    const query = {
      status: 'active',
      location: {
        $geoWithin: {
          $box: [
            [west, south], // bottom-left
            [east, north]  // top-right
          ]
        }
      }
    };

    if (category) {
      query.category = category;
    }

    const products = await Product.find(query)
      .select('name price category location address')
      .limit(500); // Limit for performance

    res.json({
      success: true,
      products
    });
  } catch (error) {
    console.error('Get map products error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get products'
    });
  }
});

/**
 * GET /api/products/:productId
 * Get product by ID
 */
app.get('/api/products/:productId', async (req, res) => {
  try {
    const { productId } = req.params;
    const product = await Product.findById(productId);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    res.json({
      success: true,
      product
    });
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get product'
    });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
