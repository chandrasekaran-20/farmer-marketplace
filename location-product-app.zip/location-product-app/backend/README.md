# Backend - Location Product API

## Installation

```bash
npm install
```

## Configuration

1. Copy `.env.example` to `.env`
2. Update environment variables with your values
3. Ensure MongoDB is running

## Running

```bash
# Development
npm run dev

# Production
npm start
```

## API Endpoints

### Location Endpoints
- POST `/api/location/geocode` - Convert address to coordinates
- POST `/api/location/reverse-geocode` - Convert coordinates to address

### Product Endpoints
- POST `/api/products` - Create product with location
- PATCH `/api/products/:id/location` - Update product location
- GET `/api/products/search/nearby` - Search products by location
- GET `/api/products/map` - Get products for map view
- GET `/api/products/:id` - Get product by ID

## MongoDB Schema

Products have geospatial location field:
```javascript
location: {
  type: 'Point',
  coordinates: [longitude, latitude]
}
```

Geospatial index is created automatically.
