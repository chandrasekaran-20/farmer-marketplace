# Location-Based Product Browsing Application

## Overview

This application enables farmers/sellers to list products with precise location information and allows buyers to search for products based on their geographic proximity. The system includes auto-detection, address autocomplete, interactive maps, and distance-based filtering.

## Features

### For Sellers (Farmers)
- ✅ **Auto-location detection** - Use current GPS location
- ✅ **Address autocomplete** - Google Places powered suggestions
- ✅ **Interactive map picker** - Drag and drop location marker
- ✅ **Manual entry fallback** - Traditional form fields
- ✅ **Location accuracy indicator** - Shows precision level
- ✅ **Update product location** - Modify location anytime

### For Buyers
- ✅ **Location-based search** - Find products near any location
- ✅ **Distance filtering** - Filter by 5km, 10km, 25km, 50km, 100km
- ✅ **Map view** - Visualize all products on interactive map
- ✅ **List view** - Traditional list with distance information
- ✅ **Category filtering** - Filter by product category
- ✅ **Search by name** - Combine location with text search

## Technology Stack

### Frontend
- React 18+
- Google Maps JavaScript API
- Google Places API
- Axios for HTTP requests
- Custom hooks (useGeolocation, useGoogleMaps)

### Backend
- Node.js with Express
- MongoDB with geospatial indexing (2dsphere)
- Google Geocoding API
- Mongoose ODM

## Prerequisites

1. **Node.js** (v14 or higher)
2. **MongoDB** (v4.0 or higher with geospatial support)
3. **Google Cloud Platform account** with:
   - Maps JavaScript API enabled
   - Places API enabled
   - Geocoding API enabled
   - Billing account set up

## Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd location-product-app
```

### 2. Backend Setup

```bash
# Navigate to backend directory (or root if backend is in root)
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env
```

Edit `.env` file with your configuration:

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# MongoDB Configuration
MONGODB_URI=mongodb://localhost:27017/farm-products

# Google Maps API Key (Server-side with IP restrictions)
GOOGLE_MAPS_API_KEY=your_server_api_key_here
```

### 3. Frontend Setup

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Create .env file
cp .env.example .env
```

Edit `.env` file:

```env
# API Configuration
REACT_APP_API_URL=http://localhost:5000/api

# Google Maps API Key (Client-side with domain restrictions)
REACT_APP_GOOGLE_MAPS_API_KEY=your_client_api_key_here
```

### 4. Google Cloud Platform Setup

#### Create Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project
3. Enable billing for the project

#### Enable Required APIs
```
1. Maps JavaScript API
2. Places API
3. Geocoding API
```

#### Create API Keys

**Server-side API Key** (for backend):
1. Create API key
2. Add IP address restrictions
3. Restrict to: Geocoding API
4. Use in backend `.env`

**Client-side API Key** (for frontend):
1. Create API key
2. Add HTTP referrer restrictions (your domain)
3. Restrict to: Maps JavaScript API, Places API
4. Use in frontend `.env`

#### Set API Quotas
- Monitor usage in Google Cloud Console
- Set budget alerts
- Configure rate limiting if needed

### 5. Database Setup

```bash
# Start MongoDB
mongod

# The application will automatically create the database and indexes
# Geospatial index is created on the 'location' field
```

To manually create the index:

```javascript
use farm-products
db.products.createIndex({ location: "2dsphere" })
```

## Running the Application

### Development Mode

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
# Server runs on http://localhost:5000
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
# App opens on http://localhost:3000
```

### Production Build

**Backend:**
```bash
cd backend
npm start
```

**Frontend:**
```bash
cd frontend
npm run build
# Serve the build folder with a static server
```

## Project Structure

```
location-product-app/
├── backend/
│   ├── server.js              # Express server with location APIs
│   ├── package.json
│   └── .env
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── seller/
│   │   │   │   ├── ProductForm.jsx
│   │   │   │   ├── LocationInput.jsx
│   │   │   │   ├── MapPicker.jsx
│   │   │   │   └── AddressAutocomplete.jsx
│   │   │   └── buyer/
│   │   │       ├── ProductSearch.jsx
│   │   │       ├── ProductMap.jsx
│   │   │       ├── LocationSearch.jsx
│   │   │       └── DistanceFilter.jsx
│   │   ├── hooks/
│   │   │   ├── useGeolocation.js
│   │   │   └── useGoogleMaps.js
│   │   ├── services/
│   │   │   ├── locationService.js
│   │   │   └── productService.js
│   │   └── App.js
│   ├── package.json
│   └── .env
├── PRD_Enhanced.md            # Product Requirements Document
├── SRD_Enhanced.md            # Software Requirements Document
└── README.md                  # This file
```

## API Endpoints

### Location Endpoints

#### POST /api/location/geocode
Convert address to coordinates

**Request:**
```json
{
  "address": "MG Road, Bangalore, Karnataka"
}
```

**Response:**
```json
{
  "success": true,
  "location": {
    "coordinates": [77.6033, 12.9716],
    "formattedAddress": "MG Road, Bangalore, Karnataka 560001, India",
    "address": {
      "street": "MG Road",
      "city": "Bangalore",
      "state": "Karnataka",
      "pinCode": "560001"
    }
  }
}
```

#### POST /api/location/reverse-geocode
Convert coordinates to address

**Request:**
```json
{
  "latitude": 12.9716,
  "longitude": 77.5946
}
```

### Product Endpoints

#### POST /api/products
Create product with location

#### PATCH /api/products/:id/location
Update product location

#### GET /api/products/search/nearby
Search products by location

**Query Parameters:**
- `latitude` (required)
- `longitude` (required)
- `radius` (km, default: 10)
- `category` (optional)
- `query` (optional)
- `page` (default: 1)
- `limit` (default: 20)

#### GET /api/products/map
Get products for map view

## Usage Guide

### For Sellers - Adding a Product

1. **Fill Product Details**
   - Enter product name, description, price, category

2. **Set Location (Choose One Method):**

   **Option A: Use Current Location**
   - Click "Use My Current Location"
   - Allow browser location permission
   - System auto-fills address

   **Option B: Search Address**
   - Start typing in address field
   - Select from autocomplete suggestions
   - Location sets automatically

   **Option C: Use Map**
   - Click "Show Map"
   - Click on map or drag marker
   - Address updates automatically

   **Option D: Manual Entry**
   - Fill in street, city, state, PIN code
   - System validates format

3. **Submit Product**
   - Review all details
   - Click "Add Product"

### For Buyers - Finding Products

1. **Set Search Location:**
   - Use "My Current Location" button, OR
   - Type location in search box

2. **Apply Filters:**
   - Select category (optional)
   - Choose distance range (5-100km)
   - Enter product name (optional)

3. **View Results:**
   - **List View**: Products sorted by distance
   - **Map View**: Interactive map with product markers

4. **Contact Seller:**
   - Click on product for details
   - See distance from your location
   - Contact seller directly

## Testing

### Manual Testing

**Test Location Detection:**
```bash
# Open browser console
# Allow location permission
# Verify coordinates match your actual location
```

**Test Geocoding:**
```bash
curl -X POST http://localhost:5000/api/location/geocode \
  -H "Content-Type: application/json" \
  -d '{"address":"Bangalore"}'
```

**Test Product Search:**
```bash
curl "http://localhost:5000/api/products/search/nearby?latitude=12.9716&longitude=77.5946&radius=10"
```

### Automated Testing

```bash
# Run backend tests
cd backend
npm test

# Run frontend tests
cd frontend
npm test
```

## Troubleshooting

### Location Not Detected

**Problem:** Browser can't access location
**Solution:**
- Check browser permissions
- Use HTTPS (HTTP geolocation is restricted)
- Try manual address entry

### Google Maps Not Loading

**Problem:** Map shows error or blank screen
**Solution:**
- Verify API key is correct
- Check API is enabled in Google Cloud
- Check domain/IP restrictions
- Review browser console for errors

### No Products Found

**Problem:** Search returns no results
**Solution:**
- Increase search radius
- Check if products exist in database
- Verify coordinates are valid
- Check MongoDB geospatial index exists

### Address Autocomplete Not Working

**Problem:** No suggestions appear
**Solution:**
- Verify Places API is enabled
- Check API key restrictions
- Ensure internet connection
- Review browser console

## Performance Optimization

### Frontend
- Lazy load map components
- Debounce autocomplete (300ms)
- Cache geocoding results
- Use marker clustering (>10 products)
- Virtual scrolling for large lists

### Backend
- Geospatial indexes on location fields
- Cache geocoding responses (Redis)
- Request throttling/rate limiting
- Connection pooling
- Result pagination

### API Costs
- Cache Google API responses (24h)
- Use browser Geolocation instead of Google
- Batch geocoding where possible
- Monitor quota usage

## Security Considerations

1. **API Keys:**
   - Use separate keys for frontend/backend
   - Implement domain/IP restrictions
   - Rotate keys periodically
   - Monitor for unusual usage

2. **Location Privacy:**
   - Request explicit permission
   - Allow opt-out of precise location
   - Consider coordinate fuzzing
   - Store minimal location data

3. **Input Validation:**
   - Validate coordinate ranges
   - Sanitize address inputs
   - Validate PIN code format
   - Rate limit API requests

## Migration Guide

To add location features to existing products:

```javascript
// migration.js
const Product = require('./models/Product');
const { geocodeAddress } = require('./services/locationService');

async function migrateProducts() {
  const products = await Product.find({ 
    location: { $exists: false } 
  });

  for (const product of products) {
    try {
      const fullAddress = `${product.street}, ${product.city}, ${product.state}, ${product.pinCode}`;
      const location = await geocodeAddress(fullAddress);
      
      product.location = {
        type: 'Point',
        coordinates: location.coordinates
      };
      product.address = location.address;
      product.locationMethod = 'migration';
      
      await product.save();
      console.log(`Migrated product: ${product._id}`);
    } catch (error) {
      console.error(`Failed to migrate ${product._id}:`, error);
    }
  }
}

migrateProducts();
```

## Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## License

MIT License - see LICENSE file

## Support

For issues or questions:
- Open GitHub issue
- Email: support@example.com
- Documentation: [docs.example.com](https://docs.example.com)

## Changelog

### Version 2.0 (Current)
- ✅ Added location-based features
- ✅ Google Maps integration
- ✅ Auto-location detection
- ✅ Address autocomplete
- ✅ Interactive map picker
- ✅ Distance-based search
- ✅ Map view for products

### Version 1.0
- Basic product listing
- PIN code only location
- Text-based search

## Roadmap

### Phase 3 (Future)
- [ ] Real-time delivery tracking
- [ ] Polygon delivery zones
- [ ] Route optimization
- [ ] Offline map caching
- [ ] Multi-language support
- [ ] Payment integration
- [ ] Rating and reviews
- [ ] Chat system

---

**Last Updated:** February 9, 2026  
**Version:** 2.0  
**Maintained by:** Development Team
