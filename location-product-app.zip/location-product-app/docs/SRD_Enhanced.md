# Software Requirements Document (SRD)
## Enhanced Location-Based Product Browsing Application

### Version: 2.0
### Date: February 9, 2026

---

## 1. Introduction

### 1.1 Purpose
This document provides detailed technical specifications for implementing location-based features in the product browsing application.

### 1.2 Scope
- Frontend implementation (React/JavaScript)
- Backend API endpoints (Node.js/Express or similar)
- Database schema modifications
- Third-party API integrations

### 1.3 Definitions
- **Geocoding**: Converting addresses to coordinates
- **Reverse Geocoding**: Converting coordinates to addresses
- **Geohashing**: Encoding geographic coordinates into short strings
- **Haversine Formula**: Calculating distances between lat/lng points

---

## 2. System Architecture

### 2.1 High-Level Architecture
```
┌─────────────┐         ┌─────────────┐         ┌──────────────┐
│   Browser   │ ←──────→│   Backend   │ ←──────→│   Database   │
│  (React)    │         │  (Node.js)  │         │  (MongoDB/   │
│             │         │             │         │   PostgreSQL)│
└─────────────┘         └─────────────┘         └──────────────┘
       ↓                        ↓
       ↓                        ↓
┌─────────────┐         ┌─────────────┐
│   Google    │         │   Google    │
│   Maps API  │         │  Places API │
└─────────────┘         └─────────────┘
```

### 2.2 Technology Stack
- **Frontend**: React 18+, React Leaflet / Google Maps React
- **Backend**: Node.js with Express.js
- **Database**: MongoDB (with geospatial indexing) or PostgreSQL (with PostGIS)
- **APIs**: Google Maps JavaScript API, Google Places API, Geocoding API
- **State Management**: React Context API / Redux
- **HTTP Client**: Axios

---

## 3. Database Design

### 3.1 Schema Updates

#### 3.1.1 Products Collection/Table (Enhanced)
```javascript
{
  _id: ObjectId,
  name: String,
  description: String,
  price: Number,
  category: String,
  sellerId: ObjectId,
  
  // NEW LOCATION FIELDS
  location: {
    type: {
      type: String,
      enum: ['Point'],
      required: true
    },
    coordinates: {
      type: [Number], // [longitude, latitude]
      required: true
    }
  },
  address: {
    street: String,
    city: String,
    state: String,
    pinCode: String,
    country: String,
    fullAddress: String
  },
  locationAccuracy: Number, // in meters
  locationMethod: String, // 'auto', 'manual', 'map'
  
  createdAt: Date,
  updatedAt: Date
}
```

#### 3.1.2 Geospatial Index (MongoDB)
```javascript
db.products.createIndex({ location: "2dsphere" })
```

#### 3.1.3 Geospatial Support (PostgreSQL)
```sql
-- Add PostGIS extension
CREATE EXTENSION IF NOT EXISTS postgis;

-- Add location column
ALTER TABLE products 
ADD COLUMN location GEOGRAPHY(Point, 4326);

-- Add address columns
ALTER TABLE products 
ADD COLUMN street VARCHAR(255),
ADD COLUMN city VARCHAR(100),
ADD COLUMN state VARCHAR(100),
ADD COLUMN pin_code VARCHAR(10),
ADD COLUMN country VARCHAR(100),
ADD COLUMN full_address TEXT,
ADD COLUMN location_accuracy DECIMAL,
ADD COLUMN location_method VARCHAR(20);

-- Create spatial index
CREATE INDEX idx_products_location ON products USING GIST(location);
```

---

## 4. API Specifications

### 4.1 Seller Endpoints

#### 4.1.1 Create Product with Location
```
POST /api/products
```

**Request Body:**
```json
{
  "name": "Fresh Tomatoes",
  "description": "Organic tomatoes from my farm",
  "price": 50,
  "category": "Vegetables",
  "location": {
    "coordinates": [77.5946, 12.9716], // [lng, lat]
    "address": {
      "street": "123 Farm Road",
      "city": "Bangalore",
      "state": "Karnataka",
      "pinCode": "560001",
      "country": "India",
      "fullAddress": "123 Farm Road, Bangalore, Karnataka 560001"
    },
    "accuracy": 10,
    "method": "auto"
  }
}
```

**Response:**
```json
{
  "success": true,
  "productId": "507f1f77bcf86cd799439011",
  "message": "Product created successfully"
}
```

#### 4.1.2 Update Product Location
```
PATCH /api/products/:productId/location
```

**Request Body:**
```json
{
  "coordinates": [77.5946, 12.9716],
  "address": {
    "street": "456 New Farm Road",
    "city": "Bangalore",
    "state": "Karnataka",
    "pinCode": "560002",
    "fullAddress": "456 New Farm Road, Bangalore, Karnataka 560002"
  }
}
```

#### 4.1.3 Geocode Address
```
POST /api/location/geocode
```

**Request Body:**
```json
{
  "address": "MG Road, Bangalore, Karnataka"
}
```

**Response:**
```json
{
  "success": true,
  "location": {
    "coordinates": [77.6033, 12.9716],
    "formattedAddress": "MG Road, Bangalore, Karnataka 560001, India",
    "address": {
      "street": "MG Road",
      "city": "Bangalore",
      "state": "Karnataka",
      "pinCode": "560001",
      "country": "India"
    }
  }
}
```

#### 4.1.4 Reverse Geocode Coordinates
```
POST /api/location/reverse-geocode
```

**Request Body:**
```json
{
  "latitude": 12.9716,
  "longitude": 77.5946
}
```

**Response:**
```json
{
  "success": true,
  "address": {
    "street": "Residency Road",
    "city": "Bangalore",
    "state": "Karnataka",
    "pinCode": "560025",
    "country": "India",
    "fullAddress": "Residency Road, Bangalore, Karnataka 560025, India"
  }
}
```

### 4.2 Buyer Endpoints

#### 4.2.1 Search Products by Location
```
GET /api/products/search/nearby
```

**Query Parameters:**
```
latitude: 12.9716
longitude: 77.5946
radius: 10 (in kilometers)
category: Vegetables (optional)
minPrice: 0 (optional)
maxPrice: 1000 (optional)
limit: 20 (default)
page: 1 (default)
```

**Response:**
```json
{
  "success": true,
  "total": 45,
  "page": 1,
  "totalPages": 3,
  "products": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "Fresh Tomatoes",
      "price": 50,
      "category": "Vegetables",
      "distance": 2.5,
      "distanceUnit": "km",
      "location": {
        "coordinates": [77.5946, 12.9716]
      },
      "address": {
        "city": "Bangalore",
        "state": "Karnataka",
        "pinCode": "560001"
      },
      "seller": {
        "name": "John Doe",
        "rating": 4.5
      }
    }
  ]
}
```

#### 4.2.2 Get Products for Map View
```
GET /api/products/map
```

**Query Parameters:**
```
bounds: 12.8,77.4,13.1,77.7 (south,west,north,east)
category: Vegetables (optional)
```

**Response:**
```json
{
  "success": true,
  "products": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "Fresh Tomatoes",
      "price": 50,
      "location": {
        "coordinates": [77.5946, 12.9716]
      },
      "thumbnail": "url-to-image"
    }
  ]
}
```

---

## 5. Frontend Components

### 5.1 Component Structure

```
src/
├── components/
│   ├── seller/
│   │   ├── ProductForm/
│   │   │   ├── ProductForm.jsx
│   │   │   ├── LocationInput.jsx
│   │   │   ├── AddressAutocomplete.jsx
│   │   │   ├── MapPicker.jsx
│   │   │   └── LocationButton.jsx
│   │   └── ProductList/
│   │       ├── ProductList.jsx
│   │       └── ProductCard.jsx
│   ├── buyer/
│   │   ├── ProductSearch/
│   │   │   ├── SearchBar.jsx
│   │   │   ├── LocationSearch.jsx
│   │   │   ├── DistanceFilter.jsx
│   │   │   └── ViewToggle.jsx
│   │   ├── ProductList/
│   │   │   ├── ProductList.jsx
│   │   │   └── ProductCard.jsx
│   │   └── ProductMap/
│   │       ├── ProductMap.jsx
│   │       ├── ProductMarker.jsx
│   │       └── MarkerCluster.jsx
│   └── common/
│       ├── Map/
│       │   ├── MapContainer.jsx
│       │   └── LocationMarker.jsx
│       └── Location/
│           └── LocationPermission.jsx
├── hooks/
│   ├── useGeolocation.js
│   ├── useGoogleMaps.js
│   └── useAddressAutocomplete.js
├── services/
│   ├── locationService.js
│   ├── productService.js
│   └── googleMapsService.js
└── utils/
    ├── distanceCalculator.js
    ├── geocoding.js
    └── mapHelpers.js
```

### 5.2 Key Component Specifications

#### 5.2.1 LocationInput Component
**Props:**
- `value`: Current location object
- `onChange`: Callback with updated location
- `required`: Boolean

**Features:**
- "Use My Location" button
- Address autocomplete
- Map picker toggle
- Manual entry fields
- Validation display

#### 5.2.2 MapPicker Component
**Props:**
- `center`: Initial map center
- `marker`: Current marker position
- `onMarkerMove`: Callback with new position
- `zoom`: Initial zoom level

**Features:**
- Draggable marker
- Search box on map
- Zoom controls
- Current location button

#### 5.2.3 ProductMap Component
**Props:**
- `products`: Array of products with locations
- `center`: Map center
- `onProductClick`: Callback when marker clicked

**Features:**
- Product markers
- Marker clustering
- Info windows on click
- Bounds adjustment

---

## 6. Business Logic

### 6.1 Distance Calculation

#### 6.1.1 Haversine Formula (JavaScript)
```javascript
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's radius in km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  
  return distance;
}

function toRad(degrees) {
  return degrees * (Math.PI / 180);
}
```

#### 6.1.2 MongoDB Geospatial Query
```javascript
db.products.aggregate([
  {
    $geoNear: {
      near: {
        type: "Point",
        coordinates: [longitude, latitude]
      },
      distanceField: "distance",
      maxDistance: radius * 1000, // convert km to meters
      spherical: true
    }
  },
  {
    $match: {
      category: "Vegetables" // optional filter
    }
  },
  {
    $project: {
      name: 1,
      price: 1,
      location: 1,
      distance: { $divide: ["$distance", 1000] } // convert to km
    }
  }
])
```

#### 6.1.3 PostgreSQL Geospatial Query
```sql
SELECT 
  id,
  name,
  price,
  ST_AsGeoJSON(location) as location,
  ST_Distance(
    location::geography,
    ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography
  ) / 1000 as distance_km
FROM products
WHERE ST_DWithin(
  location::geography,
  ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography,
  $3 * 1000
)
ORDER BY distance_km
LIMIT $4 OFFSET $5;
```

### 6.2 Location Accuracy Levels
```javascript
const ACCURACY_LEVELS = {
  HIGH: { max: 50, label: 'High accuracy' },      // < 50m
  MEDIUM: { max: 500, label: 'Medium accuracy' }, // 50m - 500m
  LOW: { max: 5000, label: 'Low accuracy' },      // 500m - 5km
  POOR: { max: Infinity, label: 'Poor accuracy' } // > 5km
};
```

---

## 7. Third-Party Integration

### 7.1 Google Maps Configuration

#### 7.1.1 Environment Variables
```env
GOOGLE_MAPS_API_KEY=your_api_key_here
GOOGLE_MAPS_LIBRARIES=places,geometry
```

#### 7.1.2 Required APIs
- Maps JavaScript API
- Places API
- Geocoding API
- Geolocation API (browser)

#### 7.1.3 API Restrictions
- HTTP referrer restrictions for frontend key
- IP address restrictions for backend key
- Daily quota limits (monitor usage)

### 7.2 Loading Google Maps Script
```javascript
export const loadGoogleMapsScript = () => {
  return new Promise((resolve, reject) => {
    if (window.google && window.google.maps) {
      resolve(window.google.maps);
      return;
    }

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${API_KEY}&libraries=places,geometry`;
    script.async = true;
    script.defer = true;
    script.onload = () => resolve(window.google.maps);
    script.onerror = reject;
    
    document.head.appendChild(script);
  });
};
```

---

## 8. Security Considerations

### 8.1 API Key Security
- Use separate keys for frontend and backend
- Implement API key restrictions (domain/IP)
- Monitor API usage for anomalies
- Rotate keys periodically

### 8.2 Location Privacy
- Request explicit permission for location access
- Allow users to opt-out of precise location
- Fuzz coordinates for privacy (optional)
- Store minimal location data

### 8.3 Input Validation
- Validate latitude range: -90 to 90
- Validate longitude range: -180 to 180
- Sanitize address inputs
- Validate PIN code format
- Rate limit API requests

---

## 9. Performance Optimization

### 9.1 Frontend Optimization
- Lazy load map components
- Debounce autocomplete requests (300ms)
- Cache geocoding results (localStorage)
- Use marker clustering for map view
- Implement virtual scrolling for product lists

### 9.2 Backend Optimization
- Create geospatial indexes on location fields
- Cache frequently accessed locations (Redis)
- Implement request throttling
- Use connection pooling for database
- Paginate search results

### 9.3 API Cost Optimization
- Cache Google API responses (24 hours)
- Batch geocoding requests where possible
- Use browser Geolocation API instead of Google when possible
- Implement request deduplication

---

## 10. Error Handling

### 10.1 Location Errors
```javascript
const LOCATION_ERRORS = {
  PERMISSION_DENIED: 'Location access denied. Please enable location services.',
  POSITION_UNAVAILABLE: 'Unable to determine location. Please try again.',
  TIMEOUT: 'Location request timed out. Please try again.',
  UNSUPPORTED: 'Geolocation is not supported by your browser.',
  GEOCODING_FAILED: 'Unable to find address. Please check and try again.',
  INVALID_COORDINATES: 'Invalid location coordinates provided.'
};
```

### 10.2 Fallback Mechanisms
- If geolocation fails → show manual entry
- If geocoding fails → allow manual coordinate entry
- If map fails to load → show text-based form
- If Places API fails → use basic text input

---

## 11. Testing Requirements

### 11.1 Unit Tests
- Distance calculation accuracy
- Coordinate validation
- Address parsing
- Geocoding service mocks

### 11.2 Integration Tests
- Google Maps API integration
- Database geospatial queries
- Location-based search accuracy
- Map marker rendering

### 11.3 E2E Tests
- Complete product creation flow with location
- Location-based search flow
- Map interaction and filtering
- Mobile touch gestures

### 11.4 Test Data
- Sample coordinates for major Indian cities
- Mock product data with varied locations
- Edge cases (polar regions, date line)

---

## 12. Deployment

### 12.1 Environment Setup
```bash
# Production
GOOGLE_MAPS_API_KEY=prod_key
DATABASE_URL=production_db_url
NODE_ENV=production

# Staging
GOOGLE_MAPS_API_KEY=staging_key
DATABASE_URL=staging_db_url
NODE_ENV=staging
```

### 12.2 Database Migration
```javascript
// Migration script
const migrateProductsLocation = async () => {
  const products = await Product.find({ pinCode: { $exists: true } });
  
  for (const product of products) {
    try {
      const location = await geocodeAddress(product.address);
      product.location = {
        type: 'Point',
        coordinates: [location.lng, location.lat]
      };
      product.locationMethod = 'migration';
      await product.save();
    } catch (error) {
      console.error(`Failed to migrate product ${product._id}`, error);
    }
  }
};
```

### 12.3 Monitoring
- API response times
- Geolocation success rate
- Search query performance
- Google Maps API quota usage
- Error rates by type

---

## 13. Acceptance Testing

### 13.1 Seller Flow Tests
- [ ] Can click "Use My Location" and see auto-filled address
- [ ] Can type address and see autocomplete suggestions
- [ ] Can select address from autocomplete and see map update
- [ ] Can drag map marker and see address update
- [ ] Can manually enter all address fields
- [ ] Can create product with location successfully
- [ ] Can update existing product location

### 13.2 Buyer Flow Tests
- [ ] Can search products near current location
- [ ] Can enter custom location for search
- [ ] Can see products sorted by distance
- [ ] Can filter by distance ranges
- [ ] Can toggle between list and map view
- [ ] Can see products on map as markers
- [ ] Can click marker and see product details
- [ ] Map view clusters markers appropriately

---

## 14. Appendix

### 14.1 Coordinate Systems
- WGS84 (EPSG:4326): Standard GPS coordinates
- Format: [longitude, latitude] (GeoJSON standard)

### 14.2 Distance Units
- Meters: Database storage
- Kilometers: Display for users
- Conversion: 1 km = 1000 m

### 14.3 Useful Resources
- Google Maps Platform: https://developers.google.com/maps
- GeoJSON Specification: https://geojson.org/
- MongoDB Geospatial Queries: https://docs.mongodb.com/manual/geospatial-queries/
- PostGIS Documentation: https://postgis.net/documentation/

---

**Document Version**: 2.0  
**Last Updated**: February 9, 2026  
**Next Review Date**: March 9, 2026
