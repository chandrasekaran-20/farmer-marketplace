# Quick Setup Guide

## Prerequisites
- Node.js 14+ installed
- MongoDB installed and running
- Google Cloud account with billing enabled

## Step 1: Install Dependencies

```bash
# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

## Step 2: Configure Environment Variables

```bash
# Backend
cd backend
cp .env.example .env
# Edit .env with your MongoDB URI and Google API key

# Frontend
cd ../frontend
cp .env.example .env
# Edit .env with your API URL and Google API key
```

## Step 3: Set Up Google Maps API

1. Go to Google Cloud Console
2. Create a new project
3. Enable these APIs:
   - Maps JavaScript API
   - Places API
   - Geocoding API
4. Create two API keys (one for frontend, one for backend)
5. Add restrictions to each key

## Step 4: Start the Application

```bash
# Terminal 1 - Start backend
cd backend
npm run dev

# Terminal 2 - Start frontend
cd frontend
npm start
```

The application will open at http://localhost:3000

## Troubleshooting

- If MongoDB connection fails, ensure MongoDB is running
- If Google Maps doesn't load, check API keys and restrictions
- See README.md for detailed troubleshooting guide

## Next Steps

- Review PRD_Enhanced.md for features
- Review SRD_Enhanced.md for technical details
- Check README.md for comprehensive documentation
