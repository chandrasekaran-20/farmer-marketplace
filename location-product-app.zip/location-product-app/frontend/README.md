# Frontend - Location Product Browser

## Installation

```bash
npm install
```

## Configuration

1. Copy `.env.example` to `.env`
2. Add your Google Maps API key
3. Update API URL if needed

## Running

```bash
npm start
```

Opens on http://localhost:3000

## Project Structure

```
src/
├── components/
│   ├── seller/     # Components for product listing
│   └── buyer/      # Components for product search
├── hooks/          # Custom React hooks
├── services/       # API service functions
└── styles.css      # Global styles
```

## Features

- Auto-location detection
- Address autocomplete
- Interactive map picker
- Distance-based search
- Map view with markers
