// productService.js - Product-related API calls with location features
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

/**
 * Create a new product with location
 */
export const createProduct = async (productData) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/products`, productData);
    return response.data;
  } catch (error) {
    console.error('Create product error:', error);
    throw new Error(error.response?.data?.message || 'Failed to create product');
  }
};

/**
 * Update product location
 */
export const updateProductLocation = async (productId, locationData) => {
  try {
    const response = await axios.patch(
      `${API_BASE_URL}/products/${productId}/location`,
      locationData
    );
    return response.data;
  } catch (error) {
    console.error('Update location error:', error);
    throw new Error(error.response?.data?.message || 'Failed to update location');
  }
};

/**
 * Search products by location with filters
 */
export const searchProductsByLocation = async (params) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products/search/nearby`, {
      params: {
        latitude: params.latitude,
        longitude: params.longitude,
        radius: params.radius || 10,
        category: params.category,
        query: params.query,
        minPrice: params.minPrice,
        maxPrice: params.maxPrice,
        page: params.page || 1,
        limit: params.limit || 20
      }
    });

    return response.data;
  } catch (error) {
    console.error('Search products error:', error);
    throw new Error(error.response?.data?.message || 'Failed to search products');
  }
};

/**
 * Get products for map view (within bounds)
 */
export const getProductsForMap = async (bounds, filters = {}) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products/map`, {
      params: {
        bounds: `${bounds.south},${bounds.west},${bounds.north},${bounds.east}`,
        category: filters.category,
        minPrice: filters.minPrice,
        maxPrice: filters.maxPrice
      }
    });

    return response.data;
  } catch (error) {
    console.error('Get products for map error:', error);
    throw new Error(error.response?.data?.message || 'Failed to get products');
  }
};

/**
 * Get product by ID
 */
export const getProductById = async (productId) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products/${productId}`);
    return response.data;
  } catch (error) {
    console.error('Get product error:', error);
    throw new Error(error.response?.data?.message || 'Failed to get product');
  }
};

/**
 * Update product
 */
export const updateProduct = async (productId, productData) => {
  try {
    const response = await axios.put(
      `${API_BASE_URL}/products/${productId}`,
      productData
    );
    return response.data;
  } catch (error) {
    console.error('Update product error:', error);
    throw new Error(error.response?.data?.message || 'Failed to update product');
  }
};

/**
 * Delete product
 */
export const deleteProduct = async (productId) => {
  try {
    const response = await axios.delete(`${API_BASE_URL}/products/${productId}`);
    return response.data;
  } catch (error) {
    console.error('Delete product error:', error);
    throw new Error(error.response?.data?.message || 'Failed to delete product');
  }
};

/**
 * Get seller's products
 */
export const getSellerProducts = async (sellerId) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products/seller/${sellerId}`);
    return response.data;
  } catch (error) {
    console.error('Get seller products error:', error);
    throw new Error(error.response?.data?.message || 'Failed to get seller products');
  }
};

export default {
  createProduct,
  updateProductLocation,
  searchProductsByLocation,
  getProductsForMap,
  getProductById,
  updateProduct,
  deleteProduct,
  getSellerProducts
};
