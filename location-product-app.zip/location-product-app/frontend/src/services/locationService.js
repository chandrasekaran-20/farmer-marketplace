// locationService.js - Location-related API calls
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

/**
 * Reverse geocode coordinates to address
 */
export const reverseGeocode = async (latitude, longitude) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/location/reverse-geocode`, {
      latitude,
      longitude
    });

    if (response.data.success) {
      return response.data.address;
    } else {
      throw new Error('Reverse geocoding failed');
    }
  } catch (error) {
    console.error('Reverse geocoding error:', error);
    throw new Error(error.response?.data?.message || 'Failed to get address from coordinates');
  }
};

/**
 * Geocode address to coordinates
 */
export const geocodeAddress = async (address) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/location/geocode`, {
      address
    });

    if (response.data.success) {
      return response.data.location;
    } else {
      throw new Error('Geocoding failed');
    }
  } catch (error) {
    console.error('Geocoding error:', error);
    throw new Error(error.response?.data?.message || 'Failed to get coordinates from address');
  }
};

/**
 * Get address suggestions (autocomplete)
 */
export const getAddressSuggestions = async (input) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/location/autocomplete`, {
      params: { input }
    });

    if (response.data.success) {
      return response.data.suggestions;
    } else {
      return [];
    }
  } catch (error) {
    console.error('Autocomplete error:', error);
    return [];
  }
};

/**
 * Calculate distance between two points (Haversine formula)
 */
export const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Earth's radius in kilometers
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  return distance; // in kilometers
};

const toRadians = (degrees) => {
  return degrees * (Math.PI / 180);
};

/**
 * Format distance for display
 */
export const formatDistance = (distanceInKm) => {
  if (distanceInKm < 1) {
    return `${Math.round(distanceInKm * 1000)}m`;
  } else if (distanceInKm < 10) {
    return `${distanceInKm.toFixed(1)}km`;
  } else {
    return `${Math.round(distanceInKm)}km`;
  }
};

/**
 * Validate coordinates
 */
export const validateCoordinates = (latitude, longitude) => {
  const lat = parseFloat(latitude);
  const lng = parseFloat(longitude);

  if (isNaN(lat) || isNaN(lng)) {
    return false;
  }

  if (lat < -90 || lat > 90) {
    return false;
  }

  if (lng < -180 || lng > 180) {
    return false;
  }

  return true;
};

/**
 * Validate PIN code (India)
 */
export const validatePinCode = (pinCode) => {
  const pinCodeRegex = /^[1-9][0-9]{5}$/;
  return pinCodeRegex.test(pinCode);
};

export default {
  reverseGeocode,
  geocodeAddress,
  getAddressSuggestions,
  calculateDistance,
  formatDistance,
  validateCoordinates,
  validatePinCode
};
