// LocationInput.jsx - Enhanced Location Input with Multiple Options
import React, { useState, useEffect, useRef } from 'react';
import MapPicker from './MapPicker';
import AddressAutocomplete from './AddressAutocomplete';
import useGeolocation from '../../hooks/useGeolocation';
import { reverseGeocode } from '../../services/locationService';
import './LocationInput.css';

const LocationInput = ({ value, onChange, required }) => {
  const [showMap, setShowMap] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);
  const [locationError, setLocationError] = useState('');
  const { getCurrentPosition, isSupported } = useGeolocation();

  const handleUseCurrentLocation = async () => {
    setIsDetecting(true);
    setLocationError('');

    try {
      const position = await getCurrentPosition();
      const { latitude, longitude, accuracy } = position;

      // Reverse geocode to get address
      const addressData = await reverseGeocode(latitude, longitude);

      const newLocation = {
        coordinates: [longitude, latitude],
        address: addressData,
        accuracy: accuracy,
        method: 'auto'
      };

      onChange(newLocation);
      setShowMap(true); // Show map for verification
    } catch (error) {
      setLocationError(error.message || 'Failed to detect location');
    } finally {
      setIsDetecting(false);
    }
  };

  const handleAddressSelect = (address, coordinates) => {
    const newLocation = {
      coordinates: coordinates,
      address: address,
      accuracy: null,
      method: 'autocomplete'
    };

    onChange(newLocation);
  };

  const handleMapChange = (coordinates, address) => {
    const newLocation = {
      coordinates: coordinates,
      address: address,
      accuracy: value.accuracy,
      method: 'map'
    };

    onChange(newLocation);
  };

  const handleManualChange = (field, fieldValue) => {
    const newAddress = {
      ...value.address,
      [field]: fieldValue
    };

    // Update full address when individual fields change
    if (field !== 'fullAddress') {
      const parts = [
        newAddress.street,
        newAddress.city,
        newAddress.state,
        newAddress.pinCode
      ].filter(Boolean);
      newAddress.fullAddress = parts.join(', ');
    }

    onChange({
      ...value,
      address: newAddress
    });
  };

  const getAccuracyLabel = () => {
    if (!value.accuracy) return '';
    
    if (value.accuracy < 50) return '🟢 High accuracy';
    if (value.accuracy < 500) return '🟡 Medium accuracy';
    if (value.accuracy < 5000) return '🟠 Low accuracy';
    return '🔴 Poor accuracy';
  };

  return (
    <div className="location-input">
      {/* Quick Actions */}
      <div className="location-actions">
        <button
          type="button"
          className="btn-location"
          onClick={handleUseCurrentLocation}
          disabled={!isSupported || isDetecting}
        >
          {isDetecting ? (
            <>
              <span className="spinner"></span> Detecting...
            </>
          ) : (
            <>
              📍 Use My Current Location
            </>
          )}
        </button>

        <button
          type="button"
          className="btn-map-toggle"
          onClick={() => setShowMap(!showMap)}
        >
          {showMap ? '📝 Hide Map' : '🗺️ Show Map'}
        </button>
      </div>

      {locationError && (
        <div className="alert alert-error">{locationError}</div>
      )}

      {value.accuracy && (
        <div className="accuracy-indicator">
          {getAccuracyLabel()} ({Math.round(value.accuracy)}m)
        </div>
      )}

      {/* Address Autocomplete */}
      <div className="form-group">
        <label>Search Address</label>
        <AddressAutocomplete
          onSelect={handleAddressSelect}
          placeholder="Start typing your address..."
        />
        <small className="help-text">
          Start typing to see suggestions, or use current location above
        </small>
      </div>

      {/* Map Picker */}
      {showMap && (
        <div className="map-section">
          <MapPicker
            center={
              value.coordinates.length > 0
                ? { lat: value.coordinates[1], lng: value.coordinates[0] }
                : { lat: 20.5937, lng: 78.9629 } // India center
            }
            marker={
              value.coordinates.length > 0
                ? { lat: value.coordinates[1], lng: value.coordinates[0] }
                : null
            }
            onMarkerMove={handleMapChange}
          />
          <small className="help-text">
            Drag the marker to adjust your exact location
          </small>
        </div>
      )}

      {/* Manual Entry Fields */}
      <div className="manual-entry">
        <h4>Or Enter Address Manually</h4>
        
        <div className="form-row">
          <div className="form-group">
            <label>Street Address</label>
            <input
              type="text"
              value={value.address.street || ''}
              onChange={(e) => handleManualChange('street', e.target.value)}
              placeholder="123 Farm Road"
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>City</label>
            <input
              type="text"
              value={value.address.city || ''}
              onChange={(e) => handleManualChange('city', e.target.value)}
              placeholder="Bangalore"
            />
          </div>

          <div className="form-group">
            <label>State</label>
            <input
              type="text"
              value={value.address.state || ''}
              onChange={(e) => handleManualChange('state', e.target.value)}
              placeholder="Karnataka"
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>PIN Code {required && '*'}</label>
            <input
              type="text"
              value={value.address.pinCode || ''}
              onChange={(e) => handleManualChange('pinCode', e.target.value)}
              placeholder="560001"
              maxLength="6"
              pattern="[0-9]{6}"
            />
          </div>

          <div className="form-group">
            <label>Country</label>
            <input
              type="text"
              value={value.address.country || 'India'}
              onChange={(e) => handleManualChange('country', e.target.value)}
              placeholder="India"
            />
          </div>
        </div>

        {/* Display selected location */}
        {value.coordinates.length > 0 && (
          <div className="selected-location">
            <strong>Selected Location:</strong>
            <p>{value.address.fullAddress || 'Address being updated...'}</p>
            <small>
              Coordinates: {value.coordinates[1].toFixed(6)}, {value.coordinates[0].toFixed(6)}
            </small>
          </div>
        )}
      </div>
    </div>
  );
};

export default LocationInput;
