// ProductForm.jsx - Enhanced Product Form with Location Features
import React, { useState, useEffect } from 'react';
import LocationInput from './LocationInput';
import './ProductForm.css';

const ProductForm = ({ existingProduct = null, onSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    location: {
      coordinates: [],
      address: {
        street: '',
        city: '',
        state: '',
        pinCode: '',
        country: 'India',
        fullAddress: ''
      },
      accuracy: null,
      method: ''
    }
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (existingProduct) {
      setFormData(existingProduct);
    }
  }, [existingProduct]);

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Product name is required';
    }

    if (!formData.price || formData.price <= 0) {
      newErrors.price = 'Valid price is required';
    }

    if (!formData.category) {
      newErrors.category = 'Category is required';
    }

    if (!formData.location.coordinates.length) {
      newErrors.location = 'Location is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Format data for API
      const productData = {
        name: formData.name,
        description: formData.description,
        price: parseFloat(formData.price),
        category: formData.category,
        location: {
          coordinates: formData.location.coordinates, // [lng, lat]
          address: formData.location.address,
          accuracy: formData.location.accuracy,
          method: formData.location.method
        }
      };

      await onSubmit(productData);
      
      // Reset form on success
      if (!existingProduct) {
        setFormData({
          name: '',
          description: '',
          price: '',
          category: '',
          location: {
            coordinates: [],
            address: {
              street: '',
              city: '',
              state: '',
              pinCode: '',
              country: 'India',
              fullAddress: ''
            },
            accuracy: null,
            method: ''
          }
        });
      }
    } catch (error) {
      setErrors({ submit: error.message || 'Failed to submit product' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLocationChange = (location) => {
    setFormData(prev => ({
      ...prev,
      location
    }));
    
    // Clear location error if location is now valid
    if (location.coordinates.length > 0 && errors.location) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.location;
        return newErrors;
      });
    }
  };

  const categories = [
    'Vegetables',
    'Fruits',
    'Grains',
    'Dairy',
    'Poultry',
    'Seeds',
    'Organic Products',
    'Other'
  ];

  return (
    <div className="product-form-container">
      <h2>{existingProduct ? 'Update Product' : 'Add New Product'}</h2>
      
      <form onSubmit={handleSubmit} className="product-form">
        {/* Product Name */}
        <div className="form-group">
          <label htmlFor="name">Product Name *</label>
          <input
            type="text"
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., Fresh Organic Tomatoes"
            className={errors.name ? 'error' : ''}
          />
          {errors.name && <span className="error-message">{errors.name}</span>}
        </div>

        {/* Description */}
        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Describe your product..."
            rows="4"
          />
        </div>

        {/* Price */}
        <div className="form-group">
          <label htmlFor="price">Price (₹ per kg/unit) *</label>
          <input
            type="number"
            id="price"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            placeholder="50"
            min="0"
            step="0.01"
            className={errors.price ? 'error' : ''}
          />
          {errors.price && <span className="error-message">{errors.price}</span>}
        </div>

        {/* Category */}
        <div className="form-group">
          <label htmlFor="category">Category *</label>
          <select
            id="category"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className={errors.category ? 'error' : ''}
          >
            <option value="">Select a category</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          {errors.category && <span className="error-message">{errors.category}</span>}
        </div>

        {/* Location Input Component */}
        <div className="form-group">
          <label>Location *</label>
          <LocationInput
            value={formData.location}
            onChange={handleLocationChange}
            required
          />
          {errors.location && <span className="error-message">{errors.location}</span>}
        </div>

        {/* Submit Button */}
        <div className="form-actions">
          <button
            type="submit"
            className="btn-primary"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Saving...' : (existingProduct ? 'Update Product' : 'Add Product')}
          </button>
        </div>

        {errors.submit && (
          <div className="error-message submit-error">{errors.submit}</div>
        )}
      </form>
    </div>
  );
};

export default ProductForm;
