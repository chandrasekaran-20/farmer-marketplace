// MapPicker.jsx - Interactive Map for Location Selection
import React, { useEffect, useRef, useState } from 'react';
import useGoogleMaps from '../../hooks/useGoogleMaps';
import { reverseGeocode } from '../../services/locationService';
import './MapPicker.css';

const MapPicker = ({ center, marker, onMarkerMove }) => {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markerInstanceRef = useRef(null);
  const { isLoaded, loadError } = useGoogleMaps();
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if (!isLoaded || !mapRef.current) return;

    // Initialize map
    const map = new window.google.maps.Map(mapRef.current, {
      center: center,
      zoom: marker ? 15 : 5,
      mapTypeControl: true,
      streetViewControl: false,
      fullscreenControl: true,
      zoomControl: true,
    });

    mapInstanceRef.current = map;

    // Add marker if location exists
    if (marker) {
      const mapMarker = new window.google.maps.Marker({
        position: marker,
        map: map,
        draggable: true,
        animation: window.google.maps.Animation.DROP,
        title: 'Drag to adjust location'
      });

      markerInstanceRef.current = mapMarker;

      // Handle marker drag
      mapMarker.addListener('dragend', async () => {
        const position = mapMarker.getPosition();
        setIsUpdating(true);

        try {
          const address = await reverseGeocode(position.lat(), position.lng());
          const coordinates = [position.lng(), position.lat()];
          onMarkerMove(coordinates, address);
        } catch (error) {
          console.error('Reverse geocoding failed:', error);
        } finally {
          setIsUpdating(false);
        }
      });
    }

    // Handle map click to add/move marker
    map.addListener('click', async (e) => {
      const clickedPosition = {
        lat: e.latLng.lat(),
        lng: e.latLng.lng()
      };

      if (!markerInstanceRef.current) {
        // Create new marker
        const newMarker = new window.google.maps.Marker({
          position: clickedPosition,
          map: map,
          draggable: true,
          animation: window.google.maps.Animation.DROP,
          title: 'Drag to adjust location'
        });

        markerInstanceRef.current = newMarker;

        // Add drag listener
        newMarker.addListener('dragend', async () => {
          const position = newMarker.getPosition();
          setIsUpdating(true);

          try {
            const address = await reverseGeocode(position.lat(), position.lng());
            const coordinates = [position.lng(), position.lat()];
            onMarkerMove(coordinates, address);
          } catch (error) {
            console.error('Reverse geocoding failed:', error);
          } finally {
            setIsUpdating(false);
          }
        });
      } else {
        // Move existing marker
        markerInstanceRef.current.setPosition(clickedPosition);
      }

      // Reverse geocode the clicked location
      setIsUpdating(true);
      try {
        const address = await reverseGeocode(clickedPosition.lat, clickedPosition.lng);
        const coordinates = [clickedPosition.lng, clickedPosition.lat];
        onMarkerMove(coordinates, address);
      } catch (error) {
        console.error('Reverse geocoding failed:', error);
      } finally {
        setIsUpdating(false);
      }
    });

    // Add search box
    const searchBox = new window.google.maps.places.SearchBox(
      document.getElementById('map-search-input')
    );

    map.addListener('bounds_changed', () => {
      searchBox.setBounds(map.getBounds());
    });

    searchBox.addListener('places_changed', () => {
      const places = searchBox.getPlaces();

      if (places.length === 0) return;

      const place = places[0];

      if (!place.geometry) return;

      // Update map center
      map.setCenter(place.geometry.location);
      map.setZoom(15);

      // Add or move marker
      const newPosition = {
        lat: place.geometry.location.lat(),
        lng: place.geometry.location.lng()
      };

      if (markerInstanceRef.current) {
        markerInstanceRef.current.setPosition(newPosition);
      } else {
        const newMarker = new window.google.maps.Marker({
          position: newPosition,
          map: map,
          draggable: true,
          title: 'Drag to adjust location'
        });

        markerInstanceRef.current = newMarker;
      }

      // Trigger reverse geocode
      setIsUpdating(true);
      reverseGeocode(newPosition.lat, newPosition.lng)
        .then(address => {
          const coordinates = [newPosition.lng, newPosition.lat];
          onMarkerMove(coordinates, address);
        })
        .catch(error => console.error('Reverse geocoding failed:', error))
        .finally(() => setIsUpdating(false));
    });

    return () => {
      if (markerInstanceRef.current) {
        markerInstanceRef.current.setMap(null);
      }
    };
  }, [isLoaded, center, marker, onMarkerMove]);

  if (loadError) {
    return (
      <div className="map-error">
        <p>⚠️ Failed to load Google Maps</p>
        <p>Please use the manual entry fields or address search above.</p>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="map-loading">
        <span className="spinner"></span>
        <p>Loading map...</p>
      </div>
    );
  }

  return (
    <div className="map-picker">
      <div className="map-search">
        <input
          id="map-search-input"
          type="text"
          placeholder="Search location on map..."
          className="map-search-input"
        />
      </div>

      <div ref={mapRef} className="map-container" />

      {isUpdating && (
        <div className="map-updating-overlay">
          <span className="spinner"></span> Updating address...
        </div>
      )}

      <div className="map-instructions">
        💡 Click on the map or drag the marker to select your location
      </div>
    </div>
  );
};

export default MapPicker;
