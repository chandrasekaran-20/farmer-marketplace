// AddressAutocomplete.jsx - Google Places Autocomplete Component
import React, { useEffect, useRef, useState } from 'react';
import useGoogleMaps from '../../hooks/useGoogleMaps';
import './AddressAutocomplete.css';

const AddressAutocomplete = ({ onSelect, placeholder }) => {
  const inputRef = useRef(null);
  const autocompleteRef = useRef(null);
  const { isLoaded, loadError } = useGoogleMaps();
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    if (!isLoaded || !inputRef.current) return;

    // Initialize Google Places Autocomplete
    const autocomplete = new window.google.maps.places.Autocomplete(inputRef.current, {
      types: ['geocode', 'establishment'],
      componentRestrictions: { country: 'IN' }, // Restrict to India
      fields: ['address_components', 'geometry', 'formatted_address']
    });

    autocompleteRef.current = autocomplete;

    // Listen for place selection
    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();

      if (!place.geometry) {
        console.error('No geometry for selected place');
        return;
      }

      // Extract address components
      const addressComponents = place.address_components || [];
      const address = extractAddressComponents(addressComponents);
      address.fullAddress = place.formatted_address;

      // Get coordinates
      const coordinates = [
        place.geometry.location.lng(),
        place.geometry.location.lat()
      ];

      onSelect(address, coordinates);
    });

    return () => {
      if (autocompleteRef.current) {
        window.google.maps.event.clearInstanceListeners(autocompleteRef.current);
      }
    };
  }, [isLoaded, onSelect]);

  const extractAddressComponents = (components) => {
    const address = {
      street: '',
      city: '',
      state: '',
      pinCode: '',
      country: 'India'
    };

    components.forEach(component => {
      const types = component.types;

      if (types.includes('street_number') || types.includes('route')) {
        address.street += component.long_name + ' ';
      }

      if (types.includes('locality') || types.includes('administrative_area_level_2')) {
        address.city = component.long_name;
      }

      if (types.includes('administrative_area_level_1')) {
        address.state = component.long_name;
      }

      if (types.includes('postal_code')) {
        address.pinCode = component.long_name;
      }

      if (types.includes('country')) {
        address.country = component.long_name;
      }
    });

    address.street = address.street.trim();
    return address;
  };

  if (loadError) {
    return (
      <div className="autocomplete-error">
        Error loading Google Maps. Please use manual entry below.
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="autocomplete-loading">
        <span className="spinner"></span> Loading autocomplete...
      </div>
    );
  }

  return (
    <div className="address-autocomplete">
      <div className="autocomplete-input-wrapper">
        <span className="search-icon">🔍</span>
        <input
          ref={inputRef}
          type="text"
          className="autocomplete-input"
          placeholder={placeholder || "Enter your address"}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
      </div>
    </div>
  );
};

export default AddressAutocomplete;
