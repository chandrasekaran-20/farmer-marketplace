// ProductSearch.jsx - Location-Based Product Search for Buyers
import React, { useState, useEffect } from 'react';
import LocationSearch from './LocationSearch';
import DistanceFilter from './DistanceFilter';
import ProductList from '../ProductList/ProductList';
import ProductMap from '../ProductMap/ProductMap';
import { searchProductsByLocation } from '../../services/productService';
import useGeolocation from '../../hooks/useGeolocation';
import './ProductSearch.css';

const ProductSearch = () => {
  const [searchLocation, setSearchLocation] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [distanceFilter, setDistanceFilter] = useState(10); // km
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'map'
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const { getCurrentPosition, isSupported } = useGeolocation();

  const categories = [
    'All Categories',
    'Vegetables',
    'Fruits',
    'Grains',
    'Dairy',
    'Poultry',
    'Seeds',
    'Organic Products',
    'Other'
  ];

  useEffect(() => {
    if (searchLocation) {
      searchProducts();
    }
  }, [searchLocation, distanceFilter, selectedCategory, page]);

  const handleUseMyLocation = async () => {
    setLoading(true);
    setError('');

    try {
      const position = await getCurrentPosition();
      setSearchLocation({
        latitude: position.latitude,
        longitude: position.longitude,
        label: 'My Location'
      });
    } catch (err) {
      setError(err.message || 'Failed to get your location');
    } finally {
      setLoading(false);
    }
  };

  const handleLocationSelect = (location) => {
    setSearchLocation(location);
    setPage(1); // Reset to first page
  };

  const searchProducts = async () => {
    if (!searchLocation) return;

    setLoading(true);
    setError('');

    try {
      const params = {
        latitude: searchLocation.latitude,
        longitude: searchLocation.longitude,
        radius: distanceFilter,
        page: page,
        limit: 20
      };

      if (searchQuery) {
        params.query = searchQuery;
      }

      if (selectedCategory && selectedCategory !== 'All Categories') {
        params.category = selectedCategory;
      }

      const response = await searchProductsByLocation(params);
      setProducts(response.products);
      setTotalPages(response.totalPages);
    } catch (err) {
      setError(err.message || 'Failed to search products');
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setPage(1);
    searchProducts();
  };

  const handleDistanceChange = (distance) => {
    setDistanceFilter(distance);
    setPage(1);
  };

  return (
    <div className="product-search-container">
      <header className="search-header">
        <h1>Find Products Near You</h1>
        <p>Discover fresh products from local farmers</p>
      </header>

      {/* Search Controls */}
      <div className="search-controls">
        <div className="search-row">
          {/* Location Search */}
          <LocationSearch
            onLocationSelect={handleLocationSelect}
            onUseMyLocation={handleUseMyLocation}
            isGeolocationSupported={isSupported}
          />

          {/* Product Name Search */}
          <div className="search-input-group">
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="search-input"
            />
            <button onClick={handleSearch} className="btn-search">
              🔍 Search
            </button>
          </div>
        </div>

        {/* Filters Row */}
        <div className="filters-row">
          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setPage(1);
            }}
            className="category-select"
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          {/* Distance Filter */}
          {searchLocation && (
            <DistanceFilter
              value={distanceFilter}
              onChange={handleDistanceChange}
            />
          )}

          {/* View Toggle */}
          <div className="view-toggle">
            <button
              className={viewMode === 'list' ? 'active' : ''}
              onClick={() => setViewMode('list')}
              title="List View"
            >
              📋 List
            </button>
            <button
              className={viewMode === 'map' ? 'active' : ''}
              onClick={() => setViewMode('map')}
              title="Map View"
            >
              🗺️ Map
            </button>
          </div>
        </div>
      </div>

      {/* Location Info */}
      {searchLocation && (
        <div className="search-info">
          <span className="location-badge">
            📍 Searching near: <strong>{searchLocation.label}</strong>
          </span>
          <span className="results-count">
            {products.length > 0 && `${products.length} products found`}
          </span>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="alert alert-error">
          {error}
        </div>
      )}

      {/* No Location Selected */}
      {!searchLocation && !loading && (
        <div className="empty-state">
          <div className="empty-icon">📍</div>
          <h3>Select Your Location</h3>
          <p>Choose your location to see available products nearby</p>
          {isSupported && (
            <button onClick={handleUseMyLocation} className="btn-primary">
              Use My Current Location
            </button>
          )}
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className="loading-state">
          <span className="spinner large"></span>
          <p>Searching for products...</p>
        </div>
      )}

      {/* Results */}
      {!loading && searchLocation && products.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">🔍</div>
          <h3>No Products Found</h3>
          <p>Try increasing your search radius or changing filters</p>
        </div>
      )}

      {!loading && products.length > 0 && (
        <>
          {viewMode === 'list' ? (
            <ProductList products={products} userLocation={searchLocation} />
          ) : (
            <ProductMap
              products={products}
              center={{
                lat: searchLocation.latitude,
                lng: searchLocation.longitude
              }}
            />
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="pagination">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="btn-pagination"
              >
                ← Previous
              </button>
              <span className="page-info">
                Page {page} of {totalPages}
              </span>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="btn-pagination"
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ProductSearch;
