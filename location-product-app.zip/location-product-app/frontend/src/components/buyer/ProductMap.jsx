// ProductMap.jsx - Display Products on Interactive Map
import React, { useEffect, useRef, useState } from 'react';
import useGoogleMaps from '../../hooks/useGoogleMaps';
import './ProductMap.css';

const ProductMap = ({ products, center }) => {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);
  const infoWindowRef = useRef(null);
  const markerClustererRef = useRef(null);
  const { isLoaded, loadError } = useGoogleMaps();
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    if (!isLoaded || !mapRef.current) return;

    // Initialize map
    const map = new window.google.maps.Map(mapRef.current, {
      center: center,
      zoom: 12,
      mapTypeControl: true,
      streetViewControl: false,
      fullscreenControl: true,
    });

    mapInstanceRef.current = map;

    // Initialize info window
    infoWindowRef.current = new window.google.maps.InfoWindow();

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add user location marker
    new window.google.maps.Marker({
      position: center,
      map: map,
      icon: {
        path: window.google.maps.SymbolPath.CIRCLE,
        scale: 10,
        fillColor: '#4285F4',
        fillOpacity: 1,
        strokeColor: '#FFFFFF',
        strokeWeight: 2,
      },
      title: 'Your Location',
      zIndex: 1000
    });

    // Add product markers
    const markers = products.map(product => {
      const marker = new window.google.maps.Marker({
        position: {
          lat: product.location.coordinates[1],
          lng: product.location.coordinates[0]
        },
        map: map,
        title: product.name,
        icon: getMarkerIcon(product.category)
      });

      // Add click listener to show product details
      marker.addListener('click', () => {
        showProductInfo(product, marker);
      });

      return marker;
    });

    markersRef.current = markers;

    // Add marker clustering (if many products)
    if (products.length > 10 && window.markerClusterer) {
      markerClustererRef.current = new window.markerClusterer.MarkerClusterer({
        map,
        markers,
      });
    }

    // Fit bounds to show all markers
    if (products.length > 0) {
      const bounds = new window.google.maps.LatLngBounds();
      bounds.extend(center);
      products.forEach(product => {
        bounds.extend({
          lat: product.location.coordinates[1],
          lng: product.location.coordinates[0]
        });
      });
      map.fitBounds(bounds);
    }

    return () => {
      markersRef.current.forEach(marker => marker.setMap(null));
      if (markerClustererRef.current) {
        markerClustererRef.current.clearMarkers();
      }
    };
  }, [isLoaded, products, center]);

  const getMarkerIcon = (category) => {
    const icons = {
      'Vegetables': '🥬',
      'Fruits': '🍎',
      'Grains': '🌾',
      'Dairy': '🥛',
      'Poultry': '🐔',
      'Seeds': '🌱',
      'Organic Products': '🌿',
      'Other': '🛒'
    };

    const emoji = icons[category] || '📦';

    // Create custom marker with emoji
    return {
      url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
        <svg width="40" height="50" xmlns="http://www.w3.org/2000/svg">
          <path d="M20 0 C8 0 0 8 0 20 C0 30 20 50 20 50 C20 50 40 30 40 20 C40 8 32 0 20 0 Z" fill="#FF6B6B" stroke="#FFFFFF" stroke-width="2"/>
          <text x="20" y="26" text-anchor="middle" font-size="20" fill="#FFFFFF">${emoji}</text>
        </svg>
      `)}`,
      scaledSize: new window.google.maps.Size(40, 50),
      anchor: new window.google.maps.Point(20, 50)
    };
  };

  const showProductInfo = (product, marker) => {
    setSelectedProduct(product);

    const contentString = `
      <div class="info-window">
        <div class="info-header">
          <h3>${product.name}</h3>
          <span class="category-badge">${product.category}</span>
        </div>
        
        <div class="info-body">
          <div class="price">₹${product.price} per kg</div>
          
          ${product.distance ? `
            <div class="distance">
              📍 ${product.distance.toFixed(1)} km away
            </div>
          ` : ''}
          
          ${product.description ? `
            <p class="description">${product.description}</p>
          ` : ''}
          
          <div class="seller-info">
            <strong>Seller:</strong> ${product.seller?.name || 'N/A'}
            ${product.seller?.rating ? `
              <span class="rating">⭐ ${product.seller.rating}</span>
            ` : ''}
          </div>
          
          <div class="address">
            <strong>Location:</strong><br/>
            ${product.address?.city || ''}, ${product.address?.state || ''}
          </div>
        </div>
        
        <div class="info-actions">
          <button class="btn-view-details" onclick="window.location.href='/products/${product._id}'">
            View Details
          </button>
          <button class="btn-contact" onclick="window.location.href='/contact/${product.seller?._id}'">
            Contact Seller
          </button>
        </div>
      </div>
    `;

    infoWindowRef.current.setContent(contentString);
    infoWindowRef.current.open(mapInstanceRef.current, marker);
  };

  if (loadError) {
    return (
      <div className="map-error">
        <p>⚠️ Failed to load Google Maps</p>
        <p>Please try refreshing the page or switch to list view.</p>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="map-loading">
        <span className="spinner large"></span>
        <p>Loading map...</p>
      </div>
    );
  }

  return (
    <div className="product-map-container">
      <div ref={mapRef} className="product-map" />
      
      <div className="map-legend">
        <h4>Legend</h4>
        <div className="legend-item">
          <span className="legend-icon" style={{ backgroundColor: '#4285F4' }}>📍</span>
          <span>Your Location</span>
        </div>
        <div className="legend-item">
          <span className="legend-icon" style={{ backgroundColor: '#FF6B6B' }}>🛒</span>
          <span>Product Locations</span>
        </div>
      </div>

      {/* Selected Product Card (optional) */}
      {selectedProduct && (
        <div className="selected-product-card">
          <button
            className="close-btn"
            onClick={() => setSelectedProduct(null)}
          >
            ✕
          </button>
          <h3>{selectedProduct.name}</h3>
          <p className="price">₹{selectedProduct.price} per kg</p>
          {selectedProduct.distance && (
            <p className="distance">📍 {selectedProduct.distance.toFixed(1)} km away</p>
          )}
          <button
            className="btn-primary"
            onClick={() => window.location.href = `/products/${selectedProduct._id}`}
          >
            View Details
          </button>
        </div>
      )}
    </div>
  );
};

export default ProductMap;
