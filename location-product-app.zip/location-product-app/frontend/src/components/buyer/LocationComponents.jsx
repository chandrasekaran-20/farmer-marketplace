// DistanceFilter.jsx - Distance Range Filter Component
import React from 'react';
import './DistanceFilter.css';

const DistanceFilter = ({ value, onChange }) => {
  const distanceOptions = [
    { value: 5, label: '5 km' },
    { value: 10, label: '10 km' },
    { value: 25, label: '25 km' },
    { value: 50, label: '50 km' },
    { value: 100, label: '100 km' }
  ];

  return (
    <div className="distance-filter">
      <label>Within:</label>
      <div className="distance-chips">
        {distanceOptions.map(option => (
          <button
            key={option.value}
            className={`chip ${value === option.value ? 'active' : ''}`}
            onClick={() => onChange(option.value)}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default DistanceFilter;


// LocationSearch.jsx - Location Search Component
import React, { useRef, useState } from 'react';
import useGoogleMaps from '../../hooks/useGoogleMaps';
import './LocationSearch.css';

const LocationSearch = ({ onLocationSelect, onUseMyLocation, isGeolocationSupported }) => {
  const inputRef = useRef(null);
  const autocompleteRef = useRef(null);
  const { isLoaded } = useGoogleMaps();
  const [inputValue, setInputValue] = useState('');

  React.useEffect(() => {
    if (!isLoaded || !inputRef.current) return;

    const autocomplete = new window.google.maps.places.Autocomplete(inputRef.current, {
      types: ['geocode'],
      componentRestrictions: { country: 'IN' }
    });

    autocompleteRef.current = autocomplete;

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();

      if (place.geometry) {
        onLocationSelect({
          latitude: place.geometry.location.lat(),
          longitude: place.geometry.location.lng(),
          label: place.formatted_address || place.name
        });
      }
    });

    return () => {
      if (autocompleteRef.current) {
        window.google.maps.event.clearInstanceListeners(autocompleteRef.current);
      }
    };
  }, [isLoaded, onLocationSelect]);

  return (
    <div className="location-search">
      <div className="search-input-group">
        <span className="location-icon">📍</span>
        <input
          ref={inputRef}
          type="text"
          placeholder="Enter your location..."
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="location-input"
        />
        {isGeolocationSupported && (
          <button
            onClick={onUseMyLocation}
            className="btn-use-location"
            title="Use my current location"
          >
            🎯
          </button>
        )}
      </div>
    </div>
  );
};

export { LocationSearch, DistanceFilter };
