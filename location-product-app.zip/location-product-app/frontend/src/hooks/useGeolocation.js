// useGeolocation.js - Custom Hook for Browser Geolocation
import { useState, useEffect } from 'react';

const useGeolocation = () => {
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    setIsSupported('geolocation' in navigator);
  }, []);

  const getCurrentPosition = (options = {}) => {
    return new Promise((resolve, reject) => {
      if (!isSupported) {
        reject(new Error('Geolocation is not supported by your browser'));
        return;
      }

      const defaultOptions = {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
        ...options
      };

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            altitude: position.coords.altitude,
            altitudeAccuracy: position.coords.altitudeAccuracy,
            heading: position.coords.heading,
            speed: position.coords.speed,
            timestamp: position.timestamp
          });
        },
        (error) => {
          let errorMessage = 'Failed to get location';

          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = 'Location access denied. Please enable location permissions in your browser settings.';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = 'Location information unavailable. Please check your device settings.';
              break;
            case error.TIMEOUT:
              errorMessage = 'Location request timed out. Please try again.';
              break;
            default:
              errorMessage = 'An unknown error occurred while getting location.';
          }

          reject(new Error(errorMessage));
        },
        defaultOptions
      );
    });
  };

  const watchPosition = (callback, errorCallback, options = {}) => {
    if (!isSupported) {
      if (errorCallback) {
        errorCallback(new Error('Geolocation is not supported'));
      }
      return null;
    }

    const defaultOptions = {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 0,
      ...options
    };

    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        callback({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude,
          altitudeAccuracy: position.coords.altitudeAccuracy,
          heading: position.coords.heading,
          speed: position.coords.speed,
          timestamp: position.timestamp
        });
      },
      (error) => {
        if (errorCallback) {
          errorCallback(error);
        }
      },
      defaultOptions
    );

    return watchId;
  };

  const clearWatch = (watchId) => {
    if (isSupported && watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
    }
  };

  return {
    isSupported,
    getCurrentPosition,
    watchPosition,
    clearWatch
  };
};

export default useGeolocation;
